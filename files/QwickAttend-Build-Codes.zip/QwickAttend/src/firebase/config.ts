export const firebaseConfig = {
  apiKey: "AIzaSyCzUfiajl1WD1ACInHxMFR46fQZO-yHaGc",
  authDomain: "sarc-qwickattend.firebaseapp.com",
  projectId: "sarc-qwickattend",
  storageBucket: "sarc-qwickattend.appspot.com",
  messagingSenderId: "883743620440",
  appId: "1:883743620440:web:a52c04e8e0d39b8817f92d",
  measurementId: "G-KKVT7KV3JC"
};