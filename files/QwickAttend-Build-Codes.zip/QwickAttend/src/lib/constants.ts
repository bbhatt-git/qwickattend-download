export const SECTIONS = [
  "SpaceX",
  "FusionX",
  "Tesla",
  "Management - Maths",
  "Management - Social",
] as const;
