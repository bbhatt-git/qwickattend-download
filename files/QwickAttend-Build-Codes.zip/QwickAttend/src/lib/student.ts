
export type Student = {
    id: string;
    name: string;
    class: string;
    section: string;
    studentId: string;
    qrCodeUrl: string;
    teacherId: string;
  };
