
'use client';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Globe, Facebook, Github, Instagram, GitBranch, Phone, Mail, Copyright, Info, QrCode, Nfc, LayoutDashboard, User, CalendarOff, FileText, Download } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Image from 'next/image';

export default function AboutPage() {
    const appVersion = "1.0.0";
    const currentYear = new Date().getFullYear();

    const features = [
        {
            icon: <QrCode className="h-6 w-6 text-primary" />,
            title: "Effortless QR Scanning",
            description: "Use your device's camera to scan student QR codes instantly."
        },
        {
            icon: <Nfc className="h-6 w-6 text-primary" />,
            title: "NFC Tag Support",
            description: "Take attendance with a tap using in-built or external NFC readers."
        },
        {
            icon: <LayoutDashboard className="h-6 w-6 text-primary" />,
            title: "Real-time Dashboard",
            description: "Get an immediate overview of today's attendance statistics."
        },
        {
            icon: <User className="h-6 w-6 text-primary" />,
            title: "Student Records",
            description: "View and manage student information and attendance history."
        },
        {
            icon: <CalendarOff className="h-6 w-6 text-primary" />,
            title: "Holiday Management",
            description: "Easily schedule single or multi-day school holidays."
        },
        {
            icon: <FileText className="h-6 w-6 text-primary" />,
            title: "Comprehensive Reports",
            description: "View detailed attendance logs by day or individual student history."
        },
        {
            icon: <Download className="h-6 w-6 text-primary" />,
            title: "Data Export",
            description: "Export monthly or summary attendance reports to PDF and Excel."
        }
    ];

    return (
        <div className="flex justify-center items-start p-2 sm:p-4">
            <Card className="w-full max-w-4xl shadow-lg">
                <CardHeader className="text-center bg-muted/50 rounded-t-lg p-6 md:p-8">
                    <div className="mx-auto w-fit mb-4">
                        <Image src="/qwickattend-logo.png" alt="QwickAttend Logo" width={100} height={100} />
                    </div>
                    <h1 className="text-3xl md:text-4xl font-bold tracking-tight">QwickAttend</h1>
                    <p className="text-md md:text-lg text-muted-foreground mt-2">
                        The seamless attendance tracking solution for modern educators.
                    </p>
                </CardHeader>
                <CardContent className="p-4 md:p-8 space-y-8">
                    
                    <div className="space-y-8">

                        {/* Developer Section */}
                        <div className="space-y-6">
                            <h2 className="text-xl md:text-2xl font-semibold">About the Developer</h2>
                            <div className='p-4 md:p-6 rounded-lg border bg-background'>
                                <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-4 mb-6">
                                    <Avatar className="h-16 w-16">
                                        <Image src="/developer.jpg" alt="Bhupesh Raj Bhatt" width={64} height={64} className="rounded-full" />
                                    </Avatar>
                                    <div className="text-center sm:text-left">
                                        <h3 className="text-xl font-bold">Bhupesh Raj Bhatt</h3>
                                        <p className="text-sm text-muted-foreground">Developer & Maintainer</p>
                                    </div>
                                </div>

                                <div className="space-y-3 text-sm flex flex-col items-center sm:items-start">
                                    <a href="mailto:hello@bbhatt.com.np" className="flex items-center gap-3 text-primary hover:underline transition-colors">
                                        <Mail className="h-5 w-5" />
                                        <span>hello@bbhatt.com.np</span>
                                    </a>
                                    <a href="tel:+9779761184935" className="flex items-center gap-3 text-primary hover:underline transition-colors">
                                       <Phone className="h-5 w-5" />
                                       <span>+977 9761184935</span>
                                    </a>
                                </div>
                                
                                <Separator className="my-6" />

                                <div className="flex items-center justify-center gap-4">
                                    <Button asChild variant="outline" size="icon" className='rounded-full h-12 w-12 hover:bg-primary/10' title="Website">
                                        <Link href="https://bbhatt.com.np" target="_blank" rel="noopener noreferrer">
                                            <Globe className="h-6 w-6" />
                                        </Link>
                                    </Button>
                                    <Button asChild variant="outline" size="icon" className='rounded-full h-12 w-12 hover:bg-primary/10' title="Facebook">
                                        <Link href="https://www.facebook.com/share/1BnJr4X2Ec/" target="_blank" rel="noopener noreferrer">
                                            <Facebook className="h-6 w-6" />
                                        </Link>
                                    </Button>
                                    <Button asChild variant="outline" size="icon" className='rounded-full h-12 w-12 hover:bg-primary/10' title="GitHub">
                                         <Link href="https://github.com/bbhatt-git" target="_blank" rel="noopener noreferrer">
                                            <Github className="h-6 w-6" />
                                        </Link>
                                    </Button>
                                    <Button asChild variant="outline" size="icon" className='rounded-full h-12 w-12 hover:bg-primary/10' title="Instagram">
                                        <Link href="https://www.instagram.com/_bbhatt?igsh=MWdjZnc3Y2t6bXp1bA==" target="_blank" rel="noopener noreferrer">
                                            <Instagram className="h-6 w-6" />
                                        </Link>
                                    </Button>
                                </div>
                            </div>
                        </div>

                        {/* About the App Section */}
                        <div className="space-y-6">
                             <h2 className="text-xl md:text-2xl font-semibold flex items-center gap-2"><Info className='h-6 w-6' /> About the App</h2>
                             <div className='p-4 md:p-6 rounded-lg border bg-background'>
                                <p className="text-muted-foreground mb-4">
                                    QwickAttend is designed to simplify and automate the attendance process for teachers, leveraging modern technology like QR codes and NFC to make tracking fast, accurate, and effortless.
                                </p>
                                <Separator />
                                <div className='mt-4 space-y-2'>
                                    <h3 className="font-semibold flex items-center gap-2"><GitBranch className="h-5 w-5" /> Version</h3>
                                    <p className='text-sm text-muted-foreground'>Current version: <strong>{appVersion}</strong></p>
                                </div>
                             </div>
                        </div>

                        {/* Key Features Section */}
                        <div className="space-y-6">
                            <h2 className="text-xl md:text-2xl font-semibold">Key Features</h2>
                            <div className='p-4 md:p-6 rounded-lg border bg-background grid gap-6 grid-cols-1 sm:grid-cols-2'>
                               {features.map((feature, index) => (
                                 <div key={index} className="flex items-start gap-4">
                                    <div className="bg-primary/10 p-3 rounded-full">
                                        {feature.icon}
                                    </div>
                                    <div>
                                        <h3 className="font-semibold">{feature.title}</h3>
                                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                                    </div>
                                 </div>
                               ))}
                            </div>
                        </div>
                    </div>

                    <Separator />

                    <div className="text-center text-sm text-muted-foreground pt-4">
                        <div className="flex flex-col md:flex-row items-center justify-center md:gap-2">
                           <div className="flex items-center">
                             <Copyright className="h-4 w-4 mr-1" />
                             <span>{currentYear} QwickAttend.</span>
                           </div>
                           <span>All Rights Reserved.</span>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
